package com.company;

import java.io.*;
import java.lang.reflect.Method;
import java.nio.file.FileAlreadyExistsException;
import java.util.Arrays;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class CacheHelper {

    private final Method method;

    public Method getMethod() {
        return method;
    }

    public CacheHelper(Method method) {
        this.method = method;
    }

    public boolean isCached() {
        return (method.isAnnotationPresent(Cache.class));
    }

    public boolean isCachedInFile() {
        return method.getAnnotation(Cache.class).cacheType() == CacheType.IN_FILE;
    }

    public String getFileNamePrefix() {
        return method.getAnnotation(Cache.class).fileNamePrefix();
    }

    public boolean isZip() {
        return (method.getAnnotation(Cache.class).zip());
    }

    public Class<?>[] getIdentityBy() {
        return method.getParameterTypes();
    }

    public boolean resultIsAssignableToList() {
        return Arrays.asList(method.getReturnType().getInterfaces()).indexOf(List.class)!=-1;
    }

    public Class<?>[] idenityArgs() {
        return (method.getAnnotation(Cache.class).identityBy());
    }

    public int listList() {
        return (method.getAnnotation(Cache.class).listList());
    }


    public String getFileName(Object[] args) {
        StringBuilder fileName = new StringBuilder(getFileNamePrefix());
        Class<?>[] parameters = getMethod().getParameterTypes();
        if (idenityArgs().length == 0) {
            for (int i = 0; i < parameters.length; i++) {
                fileName.append("_").append(parameters[i].getName()).append('_').append(args[i].hashCode());
            }
            return fileName.toString();
        }

        int[] identityVal = new int[idenityArgs().length];
        Class<?>[] identifyByFields = idenityArgs();
        int counter = 0;
        for (int i = 0; i < parameters.length && counter < identifyByFields.length; i++) {
            if (parameters[i].equals(identifyByFields[counter])) {
                identityVal[counter] = i;
                counter++;
            }
        }

        for (int arg : identityVal) {
            fileName.append("_").append(parameters[arg].getName()).append(args[arg].hashCode());
        }

        fileName.append(isZip()?".zip":".data");
        return fileName.toString();
    }


    public Object trimList(Object result) {

        if (listList() == 0 || !resultIsAssignableToList()) {
            return result;
        }
        System.out.println("Trimming list...");
        List<?> listResult = (List<?>) result;
        return listResult.subList(0, listList() - 1);
    }


    public void save(Object result, File cacheFile) throws Exception {
        try (FileOutputStream fileStream = new FileOutputStream(cacheFile);
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileStream)) {
            objectOutputStream.writeObject(result);
        } catch (NotSerializableException e) {
            throw new NotSerializableException("Результат работы метода " + getMethod().getName() +
                    " не сериализуем. Кэширование возможно только в память.");
        }
    }


    public void saveToZip(Object result, File cacheFile) throws Exception {

        try {
            if (!cacheFile.createNewFile()) throw new FileAlreadyExistsException("Файл уже существует");
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("Нет доступа к файлу");
        }

        try (FileOutputStream cacheFileStream = new FileOutputStream(cacheFile);
             GZIPOutputStream cacheZipFileStream = new GZIPOutputStream(cacheFileStream);
             ObjectOutputStream cacheWrite = new ObjectOutputStream(cacheZipFileStream)) {
            cacheWrite.writeObject(result);
        } catch (NotSerializableException e) {
            throw new NotSerializableException("Результат работы метода " + getMethod().getName() +
                    " не сериализуем. Кэширование возможно только в память.");
        }
    }

    public Object getCache(File cacheFile) throws Exception {
        System.out.println("Getting from normal file...");
        try {
            try (FileInputStream cacheFileStream = new FileInputStream(cacheFile);
                 ObjectInputStream cacheRead = new ObjectInputStream(cacheFileStream)) {
                return cacheRead.readObject();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                throw new ClassNotFoundException("Не найден класс сериализованного объекта");
            } catch (InvalidClassException e) {
                e.printStackTrace();
                throw new InvalidClassException("Класс сериализванного объекта найден, но подвергся изменениям");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new FileNotFoundException("Не обнаружен файл кэша");
        } catch (InvalidClassException e) {
            throw e;
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("Не возможно прочитать файл кэша");
        }
    }

    public Object getCacheFromZip(File cacheFile) throws Exception {
        System.out.println("Getting from zipped file...");
        try {
            try (FileInputStream cacheFileStream = new FileInputStream(cacheFile);
                 GZIPInputStream cacheZipFileStream = new GZIPInputStream(cacheFileStream);
                 ObjectInputStream cacheRead = new ObjectInputStream(cacheZipFileStream)) {
                return cacheRead.readObject();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                throw new ClassNotFoundException("Не найден класс сериализованного объекта");
            } catch (InvalidClassException e) {
                e.printStackTrace();
                throw new InvalidClassException("Класс сериализванного объекта найден, но подвергся изменениям");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new FileNotFoundException("Не обнаружен файл кэша");
        } catch (InvalidClassException e) {
            throw e;
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("Не возможно прочитать файл кэша");
        }
    }

}
