package com.company;

import java.lang.reflect.Proxy;

public class CacheProxy {
    private final String cacheDirectory;

    public CacheProxy(String cacheDirectory) {
        this.cacheDirectory = cacheDirectory;
    }

    public <T> T cache(Object cachedObject) {
        return (T) Proxy.newProxyInstance(cachedObject.getClass().getClassLoader(),
                cachedObject.getClass().getInterfaces(), new Cacher(cachedObject, cacheDirectory));
    }
}

