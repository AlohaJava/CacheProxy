package com.company;

import java.io.File;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Cacher implements InvocationHandler {
    private final Map<String, Object> objectsInMemory;
    private final Object cachedObj;
    private final String workingDir;

    public Cacher(Object cachedObj, String workingDir) {
        this.cachedObj = cachedObj;
        this.workingDir = workingDir;
        this.objectsInMemory=new HashMap<>();
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Exception {
        CacheHelper cacheHelper = new CacheHelper(method);

        if (!cacheHelper.isCached()) {
            return method.invoke(cachedObj,args);
        }

        String fileName = cacheHelper.getFileName(args);

        if (objectsInMemory.containsKey(fileName)) {
            System.out.println("Getting from memory...");
            return objectsInMemory.get(fileName);
        }

        if (cacheHelper.isCachedInFile()) {
            System.out.println("Resource cached in file, trying to get val...");

            File cacheFile = Paths.get(workingDir, fileName).toFile();

            if (!cacheFile.exists()) {
                System.out.println("Not found cache, creating...");
                Object result = method.invoke(cachedObj, args);
                if (cacheHelper.isZip())
                    cacheHelper.saveToZip(cacheHelper.trimList(result), cacheFile);
                else
                    cacheHelper.save(cacheHelper.trimList(result), cacheFile);
                return result;
            }

            if (cacheHelper.isZip()) {
                return cacheHelper.getCacheFromZip(cacheFile);
            }

            return cacheHelper.getCache(cacheFile);
        }

        Object result = method.invoke(cachedObj, args);
        objectsInMemory.put(fileName, cacheHelper.trimList(result));
        return result;
    }

}
