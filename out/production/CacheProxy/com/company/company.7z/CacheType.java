package com.company;

public enum CacheType {
    IN_FILE,
    IN_MEMORY,
}